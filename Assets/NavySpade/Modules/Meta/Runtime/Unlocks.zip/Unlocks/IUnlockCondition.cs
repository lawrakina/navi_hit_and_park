﻿namespace Core.Meta.Unlocks
{
    public interface IUnlockCondition
    {
        bool IsMatch();
    }
}